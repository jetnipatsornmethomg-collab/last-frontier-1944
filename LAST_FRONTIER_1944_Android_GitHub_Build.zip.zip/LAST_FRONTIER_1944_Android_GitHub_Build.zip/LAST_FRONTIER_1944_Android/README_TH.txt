LAST FRONTIER: 1944 — Android project (BETA)

สิ่งที่ใส่ไว้:
- ใช้เกมจาก Frontier.html เป็นตัวเกมเดิม
- เปลี่ยนชื่อที่แสดงเป็น LAST FRONTIER: 1944
- หน้าเปิดเกมแสดงภาพปกและคำว่า BETA VERSION
- ตั้งไอคอนแอปจากภาพปก
- WebView เปิดไฟล์เกมแบบ local/offline (ฟอนต์ภายนอกอาจต้องใช้อินเทอร์เน็ต)

วิธีสร้าง APK:
1. เปิดโฟลเดอร์นี้ด้วย Android Studio
2. รอให้ Gradle Sync เสร็จและติดตั้ง Android SDK Platform 35 หากระบบร้องขอ
3. เลือก Build > Build Bundle(s) / APK(s) > Build APK(s)
4. ไฟล์ APK จะอยู่ที่ app/build/outputs/apk/debug/app-debug.apk

หมายเหตุ:
ในสภาพแวดล้อมนี้ไม่มี Android SDK/Gradle จึงยังคอมไพล์ APK จริงให้ไม่ได้
โปรเจกต์นี้เป็น source project พร้อมนำไป Build เป็น APK ใน Android Studio
